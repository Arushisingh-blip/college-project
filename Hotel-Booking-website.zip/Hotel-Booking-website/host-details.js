// host-account.js – simple console log and maybe form reset simulation
console.log('Host account page loaded');

// Example: cancel button clears fields (optional)
document.querySelector('.cancel-btn')?.addEventListener('click', () => {
  if(confirm('Discard changes?')) {
    document.querySelectorAll('textarea').forEach(t => t.value = '');
  }
});