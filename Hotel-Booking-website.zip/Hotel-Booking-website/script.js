// Simple console log to confirm external JS is loaded
console.log('StayWell website — JS file loaded successfully.');

// You can add interactive features here later, e.g., mobile menu, form validation, etc.
// For now, it's a placeholder.