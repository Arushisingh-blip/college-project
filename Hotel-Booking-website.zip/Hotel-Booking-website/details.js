// details.js – lightweight interactions for the details page

console.log('Details page loaded — StayWell');

// You can add future enhancements like image gallery, sticky booking, etc.
// For now, it's a placeholder to confirm separate JS file.

// Example: smooth scroll to amenities (if needed)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
});